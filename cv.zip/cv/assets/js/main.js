document.addEventListener('DOMContentLoaded', function() {
    // Animación suave para las barras de progreso al cargar
    const bars = document.querySelectorAll('.progress');
    bars.forEach(bar => {
        const targetWidth = bar.style.width;
        bar.style.width = '0%';
        setTimeout(() => {
            bar.style.width = targetWidth;
        }, 200);
    });
});